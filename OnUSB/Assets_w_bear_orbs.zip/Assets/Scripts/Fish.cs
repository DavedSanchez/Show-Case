using UnityEngine;
	
class Fish : FishingObject {
	
	public int value;
	
}