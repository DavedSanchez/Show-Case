using UnityEngine;

class Garbage : FishingObject {}